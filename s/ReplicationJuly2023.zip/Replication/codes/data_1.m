%% Heterogeneous Paths of Industrialization: Prepare Data
%Federico Huneeus and Richard Rogerson
%Replication Code for The Review of Economic Studies
%December 2022
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Housekeeping
clear
clear global
clearvars
clearvars global
clc
close all
format bank
tic

%Directories
rawdatadir='data/raw/';
workeddatadir='data/worked/';
outdir='output/';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%PARAMETERS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Country List in Alphabetical Order
countryabb={'ARG','BOL','BRA','CHL','CHN','COL','CRI','DEW','DNK','ESP',...
    'FRA','GBR','HKG','IND','IDN','ITA','JPN','KOR','MEX','MYS','NLD',...
    'PER','PHL','SGP','SWE','THA','TWN','USA','VEN'};
countryname={'Argentina','Bolivia','Brazil','Chile','China','Colombia',...
    'Costa Rica','Germany','Denmark','Spain','France','UK','Hong-Kong',...
    'India','Indonesia','Italy','Japan','Souht Korea','Mexico','Malaysia',...
    'Netherlands','Peru','Philippines','Singapore','Sweden','Thailand',...
    'Taiwan','USA','Venezuela'};

T=150; %Maximum Number of Years
C=size(countryabb,2); %Number of countries in the analysis

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%CREATE RELEVANT SECTORAL CROSS-COUNTRY DATASET: 1950-2010
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%GGDC 10-Sector Database: Raw
ggdc10sRaw=readtable(['../' rawdatadir 'ggdc_10s.txt']);
ggdc10sRawStr=table2array(ggdc10sRaw(:,[1 4]));
ggdc10sRawNum=table2array(ggdc10sRaw(:,5:15));

%GGDC 10-Sector Database: Employment
emp10s=NaN(T,11,C);
emp=NaN(T,3,C);
for c=1:C
    temp=ggdc10sRawNum(strcmp(ggdc10sRawStr(:,1),countryabb(c)).*strcmp(ggdc10sRawStr(:,2),'EMP')==1,:);
    temp(temp(:,1)>2010,:)=NaN; %Ignore data after 2010
    if strcmp('ESP',countryabb(c)) || strcmp('FRA',countryabb(c))...
             || strcmp('DNK',countryabb(c)) || strcmp('GBR',countryabb(c))...
             || strcmp('ITA',countryabb(c)) || strcmp('NLD',countryabb(c))...
             || strcmp('SWE',countryabb(c))
        temp=temp(3:end,:); %Ignore 1948-1949
    end
    if strcmp('USA',countryabb(c))
        temp=temp(4:end,:); %Ignore 1947-1949
    end
    if strcmp('ESP',countryabb(c)) || strcmp('FRA',countryabb(c))
        temp(1,2:end)=NaN; %Ignore isolated first data in 1950
    end
    if strcmp('IDN',countryabb(c))
        temp(12,2:end)=NaN; %Ignore isolated data in 1961
    end
    if strcmp('NLD',countryabb(c))
        temp=temp(10:end,:); %Ignore 1950-1958 (due to no man-serv emp data)
    end
    temp=temp(~isnan(temp(:,2)),:); %Ignore initial years without data in agricultural employment
    emp10s(1:size(temp,1),:,c)=temp;
    emp(:,1,c)=emp10s(:,2,c); %Agriculture
    emp(:,2,c)=squeeze(nansum(emp10s(:,3:6,c),2)); %Manufacturing
    emp(:,3,c)=squeeze(nansum(emp10s(:,7:11,c),2)); %Services
end
emp(emp==0)=NaN;

%Fixing Inconsistencies Between Different Variables
emp(57,:,strcmp('FRA',countryabb))=NaN; %Erase 2010 of France because it does not have VA
emp(55,:,strcmp('ESP',countryabb))=NaN; %Erase 2010 of Spain because it does not have VA
emp(60,:,strcmp('ITA',countryabb))=NaN; %Erase 2010 of Italy because it does not have VA
emp(52,:,strcmp('NLD',countryabb))=NaN; %Erase 2010 of Netherlands because it does not have VA

%GGDC 10-Sector Database: Real Value Added relative to 2005
rva10s=NaN(T,11,C);
rva=NaN(T,3,C);
for c=1:C
    temp=ggdc10sRawNum(strcmp(ggdc10sRawStr(:,1),countryabb(c)).*strcmp(ggdc10sRawStr(:,2),'VA_Q05')==1,:);
    temp(temp(:,1)>2010,:)=NaN; %Ignore data after 2010
    if strcmp('ESP',countryabb(c)) || strcmp('FRA',countryabb(c))...
             || strcmp('DNK',countryabb(c)) || strcmp('GBR',countryabb(c))...
             || strcmp('ITA',countryabb(c)) || strcmp('NLD',countryabb(c))...
             || strcmp('SWE',countryabb(c)) || strcmp('USA',countryabb(c))
        temp=temp(4:end,:); %Ignore 1947-1949
    end
    if strcmp('PER',countryabb(c)) || strcmp('IND',countryabb(c))...
             || strcmp('NLD',countryabb(c)) || strcmp('THA',countryabb(c))
        temp=temp(11:end,:); %Ignore 1950-1959 (because employment data is not available before)
    end
    if strcmp('ESP',countryabb(c))
        temp=temp(7:end,:); %Ignore 1950-1955 (because employment data is not available before)
    end
    if strcmp('FRA',countryabb(c))
        temp=temp(5:end,:); %Ignore 1950-1953 (because employment data is not available before)
    end
    if strcmp('IDN',countryabb(c)) || strcmp('PHL',countryabb(c))
        temp=temp(22:end,:); %Ignore 1950-1970 (because employment data is not available before)
    end
    if strcmp('KOR',countryabb(c)) || strcmp('TWN',countryabb(c))
        temp=temp(14:end,:); %Ignore 1950-1962 (because employment data is not available before)
    end
    if strcmp('MYS',countryabb(c))
        temp=temp(26:end,:); %Ignore 1950-1974 (because employment data is not available before)
    end
    if strcmp('SGP',countryabb(c))
        temp=temp(21:end,:); %Ignore 1950-1969 (because employment data is not available before)
    end
    temp=temp(~isnan(temp(:,2)),:); %Ignore initial years without data in agricultural employment
    rva10s(1:size(temp,1),:,c)=temp;
    rva(:,1,c)=rva10s(:,2,c); %Agriculture
    rva(:,2,c)=squeeze(nansum(rva10s(:,3:6,c),2)); %Manufacturing
    rva(:,3,c)=squeeze(nansum(rva10s(:,7:11,c),2)); %Services
end
rva(rva==0)=NaN;

%GGDC 10-Sector Database: Nominal Value Added
%Don't clean EU countries because they have data too late (after 1970)
%Ignore other LA countries because they have data late (due to
%hyperinflation)
nva10s=NaN(T,11,C);
nva=NaN(T,3,C);
for c=1:C
    temp=ggdc10sRawNum(strcmp(ggdc10sRawStr(:,1),countryabb(c)).*strcmp(ggdc10sRawStr(:,2),'VA')==1,:);
    temp(temp(:,1)>2010,:)=NaN; %Ignore data after 2010
    if strcmp('USA',countryabb(c))
        temp=temp(4:end,:); %Ignore 1947-1949
    end
    if strcmp('IND',countryabb(c)) || strcmp('PER',countryabb(c))...
             || strcmp('THA',countryabb(c))
        temp=temp(11:end,:); %Ignore 1950-1959 (because employment data is not available before)
    end
    if strcmp('IDN',countryabb(c))
        temp=temp(22:end,:); %Ignore 1950-1970 (because employment data is not available before)
    end
    if strcmp('KOR',countryabb(c)) || strcmp('TWN',countryabb(c))
        temp=temp(14:end,:); %Ignore 1950-1962 (because employment data is not available before)
    end
    if strcmp('MYS',countryabb(c))
        temp=temp(26:end,:); %Ignore 1950-1974 (because employment data is not available before)
    end
    temp=temp(~isnan(temp(:,2)),:); %Ignore initial years without data in agricultural employment
    nva10s(1:size(temp,1),:,c)=temp;
    nva(:,1,c)=nva10s(:,2,c); %Agriculture
    nva(:,2,c)=squeeze(nansum(nva10s(:,3:6,c),2)); %Manufacturing
    nva(:,3,c)=squeeze(nansum(nva10s(:,7:11,c),2)); %Services
end
nva(nva==0)=NaN;
clear temp

clear ggdc10sRaw ggdc10sRawNum ggdc10sRawStr

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%USA HISTORIC EMPLOYMENT 1880-2008
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Historical US Database: Raw
historicalUSARaw=readtable(['../' rawdatadir 'historicalUSA.txt']);
historicalUSARawNum=table2array(historicalUSARaw(:,:));

%Historical US Employment Levels
usahistemp=historicalUSARawNum(historicalUSARawNum(:,1)>=1880,8:11); %1880-2008
usahistemp=usahistemp(~isnan(usahistemp(:,1)),:); %Erase years with NaN

%Historical US Employment Shares
usahistempsh=usahistemp(:,1:3)./repmat(sum(usahistemp(:,1:3),2),1,3);
for j=1:75
    usahistempsh(8+j,:)=sum(usahistempsh(j+8-2:j+8+2,:))/5; %Smoothing year-by-year series
end

clear historicalUSARaw historicalUSARawNum

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%HISTORICAL CURRENT ACCOUNT DATA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

exportsWBRaw=readtable(['../' rawdatadir 'exports_wb.xls'],'Sheet','Data','Range','A4:BK268');
exports=table2array(exportsWBRaw(:,5:end));

importsWBRaw=readtable(['../' rawdatadir 'imports_wb.xls'],'Sheet','Data','Range','A4:BK268');
imports=table2array(importsWBRaw(:,5:end));

country_ca_nameAll=table2array(exportsWBRaw(:,1:2));
ca_surplusAll=(exports'-imports')./100;
Y_ca=size(ca_surplusAll,1); %Number of years: 1960-2018

%tradeTaiwanRaw=readtable(['../' rawdatadir 'trade_taiwan.xlsx'],'Sheet','trade','Range','A10:C68');
exportsTaiwanRaw=readtable(['../' rawdatadir 'taiwan_exports.xls'],'Sheet','FRED Graph','Range','B35:B73');
importsTaiwanRaw=readtable(['../' rawdatadir 'taiwan_imports.xls'],'Sheet','FRED Graph','Range','B31:B69');
%gdpTaiwanRaw=readtable(['../' rawdatadir 'gdp_taiwan.xls'],'Sheet','FRED Graph','Range','A21:B78');
gdpTaiwanRaw=readtable(['../' rawdatadir 'taiwan_gdp.xls'],'Sheet','NGDPD','Range','B3:AN3');
%gdp_taiwan=[table2array(gdpTaiwanRaw(:,2));NaN];
%ca_surplus_taiwan=(table2array(tradeTaiwanRaw(:,2))-table2array(tradeTaiwanRaw(:,3)))./gdp_taiwan;
ca_surplus_taiwan=(table2array(exportsTaiwanRaw)-table2array(importsTaiwanRaw))./(table2array(gdpTaiwanRaw)');
ca_surplus_taiwan=ca_surplus_taiwan./1000000000;

%Selection for Visualization
country_ca_name={'China','India','Indonesia','South Korea','Malaysia','Philippines',...
    'Thailand','Taiwan'}';
country_ca_nameabb={'CHN','IND','IDN','KOR','MYS','PHL','THA','TWN'}';
ca_surplusPrev=NaN(Y_ca,size(country_ca_nameabb,1));
for c=1:size(country_ca_nameabb,1)
    if max(strcmp(country_ca_nameAll(:,2),country_ca_nameabb(c)))==1
        ca_surplusPrev(:,c)=ca_surplusAll(:,strcmp(country_ca_nameAll(:,2),country_ca_nameabb(c)));
    end
end
ca_surplusPrev(21:end,8)=ca_surplus_taiwan; %1980-2018
ca_surplus=NaN(T,size(country_ca_nameabb,1)); %Allocate to correct years as in GGDC 10s Dataset
for c=1:size(country_ca_nameabb,1)
    yeari=min(emp10s(:,1,strcmp(countryabb,country_ca_nameabb{c,1})));
    if yeari>=1960
        ca_surplus(:,c)=[ca_surplusPrev(yeari-1960+1:end,c);NaN(T-(Y_ca-abs(yeari-1960)),1)];
    else
        ca_surplus(:,c)=[NaN(1960-yeari,1);ca_surplusPrev(:,c);NaN(T-Y_ca-abs(yeari-1960),1)];        
    end
end

clear exportsWBRaw exports importsWBRaw imports country_ca_nameAll ca_surplusAll Y_ca ...
    tradeTaiwanRaw gdpTaiwanRaw ca_surplus_taiwan ca_surplusPrev yeari

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%SAVE DATASET
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear c C j T

save(['../' workeddatadir 'data'])
clear outdir rawdatadir workeddatadir
