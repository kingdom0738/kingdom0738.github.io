%% Heterogeneous Paths of Industrialization: Main Analysis
%Federico Huneeus and Richard Rogerson
%Replication Code for The Review of Economic Studies
%December 2022
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Housekeeping
clear
clear global
clearvars
clearvars global
clc
close all
format bank
tic

%Directories
rawdatadir='data/raw/';
workeddatadir='data/worked/';
outdir='output/';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%PARAMETERS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

T=150;
ga=1.0239;gm=1.0225;gs=1.0147;

%Benchmark Model
alpha_a=0.02; %Long-run agricultural share of employment and GDP
cbar_a=(0.5-alpha_a)/(1-alpha_a);
alpha_m=0.42;
sigma=0.35;
cbar_s=0;

Aa=ones(T,1);
Am=ones(T,1);
As=ones(T,1);
for t=2:T
    Aa(t)=ga*Aa(t-1);
    Am(t)=gm*Am(t-1);
    As(t)=gs*As(t-1);
end

linewidth=1.5;

blue=[0 0.4470 0.7410];
orange=[0.8500 0.3250 0.0980];
yellow=[0.9290 0.6940 0.1250];
purple=[0.4940 0.1840 0.5560];
green=[0.4660 0.6740 0.1880];
lightblue=[0.3010 0.7450 0.9330];
red=[0.6350 0.0780 0.1840];
calypso=[0 0.75 0.75];
magenta=[0.75 0 0.75];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%PREPARE DATA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Load Data
load(['../' workeddatadir 'data'])

%Country List in Order from GGDC Dataset
%But using ISO codes of countries (only germany changes)
countryabb={'ARG','BOL','BRA','CHL','CHN','COL','CRI','DEU','DNK','ESP',...
    'FRA','GBR','HKG','IND','IDN','ITA','JPN','KOR','MEX','MYS','NLD',...
    'PER','PHL','SGP','SWE','THA','TWN','USA','VEN'};
countryname={'Argentina','Bolivia','Brazil','Chile','China','Colombia',...
    'Costa Rica','West Germany','Denmark','Spain','France','UK','Hong-Kong',...
    'India','Indonesia','Italy','Japan','Souht Korea','Mexico','Malaysia',...
    'Netherlands','Peru','Philippines','Singapore','Sweden','Thailand',...
    'Taiwan','USA','Venezuela'};
C=size(countryabb,2); %Number of countries in the analysis

%Country List with Full Hump Path
manuf_peak_list={'ARG','BOL','BRA','CHL','COL','CRI','DNK','FRA','IDN',...
    'ITA','JPN','KOR','MEX','MYS','PER','PHL','ESP','TWN','VEN'}';
manuf_peak_listDum=zeros(C,1);
for c=1:size(manuf_peak_list,1)
    manuf_peak_listDum=max(manuf_peak_listDum,strcmp(countryabb,manuf_peak_list(c))');
end
manuf_peak_listDum=(manuf_peak_listDum==1);

%Country List with Reasonable Nominal Value Added
%nva_good_list={'CHL','CHN','COL','CRI','KOR','IDN','IND','JPN','MEX','MYS','PER','THA','TWN'}';
nva_good_list={'CHN','COL','CRI','KOR','IDN','IND','JPN','MEX','MYS','PHL','THA','TWN'}';

%3-Sectors Employment Shares of GGDC
empsh=emp./repmat(sum(emp,2),1,3,1);

%3-Sectors Nominal Value-Added Shares of GGDC
vash=nva./repmat(sum(nva,2),1,3,1);

%3-Sectors Labor Productivity Levels
prod=rva./emp;

%3-Sectors Labor Productivity Growth
prodgr=log(prod(2:T,:,:))-log(prod(1:T-1,:,:));

%3-Sectors Price Levels
price=nva./rva;

%3-Sectors Price Growth
pricegr=log(price(2:T,:,:))-log(price(1:T-1,:,:));

%USA Historic Decadal Employment Share Evolution 1880-2000
usahistempshdec_initialYr=1880;
usahistempshdec_finalYr=2000;
usahistempshdec_DecN=1+(usahistempshdec_finalYr-usahistempshdec_initialYr)/10;
usahistempshdec=NaN(usahistempshdec_DecN,3);
usahistempshdec(1:5,:)=usahistempsh(1:5,:); %1880-1920
for t=6:usahistempshdec_DecN
    usahistempshdec(t,:)=usahistempsh(6+1+10*(t-6),:); %1930-2000    
end

%Average Productivity Growth of Manufacturing Relative to Services
prodgr_ms_primal=NaN(C,1);
prodgr_ms_dual=NaN(C,1);
for c=1:C
    %Primal approach using real productivity data
    prodgr_ms_primal(c,1)=mean(prodgr(~isnan(prodgr(:,2,c)),2,c))-mean(prodgr(~isnan(prodgr(:,3,c)),3,c));
    %Dual approach with price data
    prodgr_ms_dual(c,1)=mean(pricegr(~isnan(pricegr(:,3,c)),3,c))-mean(pricegr(~isnan(pricegr(:,2,c)),2,c));
end

%Manufacturing Employment Share Peak
[empsh_m_peak,empsh_m_peak_i]=max(empsh(:,2,:),[],1);
empsh_m_peak=squeeze(empsh_m_peak);
empsh_m_peak_i=squeeze(empsh_m_peak_i);

%Non-Agricultural Employment in Manufacturing Employment Share Peak
empsh_na_peak=NaN(C,1);
for c=1:C
    empsh_na_peak(c,1)=1-empsh(empsh_m_peak_i(c),1,c);    
end

%Correlation Between Manufacturing and Non-Agricultural Level of Peak
empsh_m_peak_final=NaN(size(manuf_peak_list,1),1);
empsh_na_peak_final=NaN(size(manuf_peak_list,1),1);
for c=1:size(manuf_peak_list,1)
    empsh_m_peak_final(c,1)=empsh_m_peak(strcmp(countryabb,manuf_peak_list(c)),1);
    empsh_na_peak_final(c,1)=empsh_na_peak(strcmp(countryabb,manuf_peak_list(c)),1);
end
B=regress(empsh_m_peak_final,[ones(size(manuf_peak_list,1),1) empsh_na_peak_final]);
empsh_m_peak_final_fit=[ones(size(manuf_peak_list,1),1) empsh_na_peak_final]*B;

%Productivity Growth Before Manufacturing Peak
prodgr_a_befpeak=NaN(C,1);
prodgr_ms_befpeak=NaN(C,1);
for c=1:C
    %Agriculture
    prodgr_a_befpeak(c,1)=squeeze(mean(prodgr(1:empsh_m_peak_i(c,1)-1,1,c),1));
    %Manufacturing-to-Services
    prodgr_ms_befpeak(c,1)=squeeze(mean(prodgr(1:empsh_m_peak_i(c,1)-1,2,c)-prodgr(1:empsh_m_peak_i(c,1)-1,3,c),1));
end

%Project Employment Shares on Non-Agricultural Employment Share
empsh_smooth1=NaN(T,C);
empsh_smooth2=NaN(50,C);
empsh_smooth2_x=NaN(50,C);
B=NaN(6,C);
for c=1:C
    z=squeeze(empsh(:,:,c));z(:,1)=1-z(:,1);
    B(:,c)=regress(z(:,2),[ones(size(z(:,1))) z(:,1) z(:,1).^2 z(:,1).^3 z(:,1).^4 z(:,1).^5]);
    empsh_smooth1(:,c)=[ones(size(z(:,1))) z(:,1) z(:,1).^2 z(:,1).^3 z(:,1).^4 z(:,1).^5]*B(:,c);
    zvec=linspace(min(z(:,1)),max(z(:,1)),50)';
    empsh_smooth2(:,c)=[ones(size(zvec)) zvec zvec.^2 zvec.^3 zvec.^4 zvec.^5]*B(:,c);
    empsh_smooth2_x(:,c)=zvec;
end

%Average Behavior for Figure 2
zvecadvavg=(.6:.01:.9)';
zpolv=[ones(size(zvecadvavg)) zvecadvavg zvecadvavg.^2 zvecadvavg.^3 zvecadvavg.^4 zvecadvavg.^5];
advavglist={'JPN','KOR','TWN','ITA','ESP'}';
y=NaN(size(zvecadvavg,1),size(advavglist,1));
for c=1:size(advavglist,1)
    y(:,c)=zpolv*B(:,strcmp(countryabb,advavglist(c)));
end
manadvavg=mean(y,2);

%Project Current Account Surplus on Non-Agricultural Employment Share
Cca=size(country_ca_name,1);
ca_smooth1=NaN(T,Cca);
ca_smooth2=NaN(50,Cca);
B=NaN(6,Cca);
for c=1:Cca
    z=squeeze(empsh(:,:,strcmp(countryabb,country_ca_nameabb{c,1})));z(:,1)=1-z(:,1);
    z(isnan(ca_surplus(:,c)),:)=NaN;
    B(:,c)=regress(ca_surplus(:,c),[ones(size(z(:,1))) z(:,1) z(:,1).^2 z(:,1).^3 z(:,1).^4 z(:,1).^5]);
    ca_smooth1(:,c)=[ones(size(z(:,1))) z(:,1) z(:,1).^2 z(:,1).^3 z(:,1).^4 z(:,1).^5]*B(:,c);
    zvec=linspace(min(z(:,1)),max(z(:,1)),50)';
    ca_smooth2(:,c)=[ones(size(zvec)) zvec zvec.^2 zvec.^3 zvec.^4 zvec.^5]*B(:,c);
end
clear ca_smooth1

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%SOLVING THE MODEL AND COUNTERFACTUALS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%Benchmark Model

%Employment
ha=alpha_a+cbar_a./Aa+alpha_a*(cbar_s./As-cbar_a./Aa); %Equation 3.2.
hm=(1-alpha_a)*(alpha_m^sigma).*(1-cbar_a./Aa+cbar_s./As)./(alpha_m^sigma+((1-alpha_m)^sigma).*((Am./As).^(1-sigma))); %Equation 3.3.
hs=1-ha-hm;

%Prices
pm(T)=1;pa(T)=Am(T)/Aa(T);ps(T)=Am(T)/As(T);
pm=pm(T)*Am(T)./Am;
pa=pa(T)*Aa(T)./Aa;
ps=ps(T)*As(T)./As;

%Counterfactual 1: Fit of Agricultural Productivity
ga_cfa=[1.0239 1.0200 1.0150 1.0100 1.0050];
ga_cfa_str={'g_a=1.0239','g_a=1.0200','g_a=1.0150','g_a=1.0100','g_a=1.0050'};
Aa_cfa=ones(T,size(ga_cfa,2));
for t=2:T
    Aa_cfa(t,:)=ga_cfa.*Aa_cfa(t-1,:);
end
ha_cfa=alpha_a+cbar_a./Aa_cfa+alpha_a*(cbar_s./As-cbar_a./Aa_cfa); %Equation 3.2.
hm_cfa=(1-alpha_a)*(alpha_m^sigma).*(1-cbar_a./Aa_cfa+cbar_s./As)./(alpha_m^sigma+((1-alpha_m)^sigma).*((Am./As).^(1-sigma))); %Equation 3.3.

%Counterfactual 2: Fit of Service Productivity
gs_cfs=[1.0147 1.0125 1.0100 1.0075 1.0050 1.0025];
gs_cfs_str={'g_s=1.0147','g_s=1.0125','g_s=1.0100','g_s=1.0075','g_s=1.0050','g_s=1.0025'};
As_cfs=ones(T,size(gs_cfs,2));
for t=2:T
    As_cfs(t,:)=gs_cfs.*As_cfs(t-1,:);
end
hm_cfs=(1-alpha_a)*(alpha_m^sigma).*(1-cbar_a./Aa+cbar_s./As_cfs)./(alpha_m^sigma+((1-alpha_m)^sigma).*((Am./As_cfs).^(1-sigma))); %Equation 3.3.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%INVERTING THE MODEL
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%Benchmark (assuming cbar_s=0)

%Recovering Agricultural Productivity Levels
Aa_inv=squeeze(cbar_a*(1-alpha_a)./(empsh(:,1,:)-alpha_a)); %Equation 6.1.

%Recovering Manufacturing Productivity Levels
%Relative to Service Productivity
AmAs_inv=squeeze((((alpha_m/(1-alpha_m))^sigma).*((1-empsh(:,1,:))./empsh(:,2,:)-1)).^(1/(1-sigma))); %Equation 6.2.

%Productivity Growth Before Manufacturing Peak
prodgr_a_befpeak_m=NaN(C,1);
prodgr_ms_befpeak_m=NaN(C,1);
for c=1:C
    %Agricultural
    prodgr_a_befpeak_m(c,1)=mean(log(Aa_inv(2:empsh_m_peak_i(c),c)./Aa_inv(1:empsh_m_peak_i(c)-1,c)));
    %Manufacturing-to-Services
    prodgr_ms_befpeak_m(c,1)=mean(log(AmAs_inv(2:empsh_m_peak_i(c),c)./AmAs_inv(1:empsh_m_peak_i(c)-1,c)));    
end

%Counterfactual 3: Role of Agricultural Productivity for Manufacturing Peak
empsh_m_peak_onlya=NaN(C,1);
for c=1:C
    Aa_cfm=NaN(T,1);
    Am_cfm=NaN(T,1);
    As_cfm=NaN(T,1);
    Aa_cfm(1)=Aa_inv(1,c);
    As_cfm(1)=prod(1,3,c);
    Am_cfm(1)=AmAs_inv(1,c).*As_cfm(1);
    for t=2:T
        Aa_cfm(t,:)=(1+prodgr_a_befpeak(c,1)).*Aa_cfm(t-1,:);
        Am_cfm(t,:)=gm.*Am_cfm(t-1,:);
        As_cfm(t,:)=gs.*As_cfm(t-1,:);
    end
    ha_cfm=alpha_a+cbar_a./Aa_cfm+alpha_a*(cbar_s./As_cfm-cbar_a./Aa_cfm); %Equation 3.2.
    hm_cfm=(1-alpha_a)*(alpha_m^sigma).*(1-cbar_a./Aa_cfm+cbar_s./As_cfm)./(alpha_m^sigma+((1-alpha_m)^sigma).*((Am_cfm./As_cfm).^(1-sigma))); %Equation 3.3.
    [empsh_m_peak_onlya(c,1),temp]=max(hm_cfm);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FIGURES
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fign=1;
f1=figure(fign);
plot(empsh_smooth2_x(:,strcmp(countryabb,'KOR')),empsh_smooth2(:,strcmp(countryabb,'KOR')),'LineWidth',linewidth,'Color',blue)
hold on
plot(empsh_smooth2_x(:,strcmp(countryabb,'MEX')),empsh_smooth2(:,strcmp(countryabb,'MEX')),'LineWidth',linewidth,'Color',yellow)
hold on
plot(empsh_smooth2_x(:,strcmp(countryabb,'BRA')),empsh_smooth2(:,strcmp(countryabb,'BRA')),'LineWidth',linewidth,'Color',orange)
hold on
plot(empsh_smooth2_x(:,strcmp(countryabb,'IDN')),empsh_smooth2(:,strcmp(countryabb,'IDN')),'LineWidth',linewidth,'Color',purple)
xlabel('Non-Agricultural Employment Share')
ylabel('Manufacturing Employment Share')
axis([0.3 1 0.05 0.35])
legend('South Korea','Mexico','Brazil','Indonesia','Location','best')
legend boxoff
hold off
saveas(f1,['../' outdir 'f1.jpg'])

fign=fign+1;
f2=figure(fign);
plot(empsh_smooth2_x(:,strcmp(countryabb,'KOR')),empsh_smooth2(:,strcmp(countryabb,'KOR')),'LineWidth',linewidth,'Color',orange)
hold on
plot(empsh_smooth2_x(:,strcmp(countryabb,'JPN')),empsh_smooth2(:,strcmp(countryabb,'JPN')),'LineWidth',linewidth,'Color',blue)
hold on
plot(empsh_smooth2_x(:,strcmp(countryabb,'TWN')),empsh_smooth2(:,strcmp(countryabb,'TWN')),'LineWidth',linewidth,'Color',yellow)
hold on
plot(empsh_smooth2_x(:,strcmp(countryabb,'FRA')),empsh_smooth2(:,strcmp(countryabb,'FRA')),'LineWidth',linewidth,'Color',purple)
hold on
plot(empsh_smooth2_x(:,strcmp(countryabb,'ITA')),empsh_smooth2(:,strcmp(countryabb,'ITA')),'LineWidth',linewidth,'Color',green)
hold on
plot(empsh_smooth2_x(:,strcmp(countryabb,'ESP')),empsh_smooth2(:,strcmp(countryabb,'ESP')),'LineWidth',linewidth,'Color',lightblue)
hold on
plot(empsh_smooth2_x(:,strcmp(countryabb,'DNK')),empsh_smooth2(:,strcmp(countryabb,'DNK')),'LineWidth',linewidth,'Color',red)
hold on
plot(zvecadvavg,manadvavg,'LineWidth',3.5,'Color','k')
xlabel('Non-Agricultural Employment Share')
ylabel('Manufacturing Employment Share')
axis([0.3 1 0.1 0.45])
legend('South Korea','Japan','Taiwan','France','Italy','Spain','Denmark','Average','Location','best')
legend boxoff
hold off
saveas(f2,['../' outdir 'f2.jpg'])

fign=fign+1;
f3=figure(fign);
plot(empsh_smooth2_x(:,strcmp(countryabb,'KOR')),empsh_smooth2(:,strcmp(countryabb,'KOR')),'LineWidth',linewidth,'Color',orange)
hold on
plot(empsh_smooth2_x(:,strcmp(countryabb,'JPN')),empsh_smooth2(:,strcmp(countryabb,'JPN')),'LineWidth',linewidth,'Color',blue)
hold on
plot(empsh_smooth2_x(:,strcmp(countryabb,'TWN')),empsh_smooth2(:,strcmp(countryabb,'TWN')),'LineWidth',linewidth,'Color',yellow)
hold on
plot(empsh_smooth2_x(:,strcmp(countryabb,'FRA')),empsh_smooth2(:,strcmp(countryabb,'FRA')),'LineWidth',linewidth,'Color',purple)
hold on
plot(empsh_smooth2_x(:,strcmp(countryabb,'ITA')),empsh_smooth2(:,strcmp(countryabb,'ITA')),'LineWidth',linewidth,'Color',green)
hold on
plot(empsh_smooth2_x(:,strcmp(countryabb,'ESP')),empsh_smooth2(:,strcmp(countryabb,'ESP')),'LineWidth',linewidth,'Color',lightblue)
hold on
plot(empsh_smooth2_x(:,strcmp(countryabb,'DNK')),empsh_smooth2(:,strcmp(countryabb,'DNK')),'LineWidth',linewidth,'Color',calypso)
hold on
plot(1-usahistempsh(1:53,1),usahistempsh(1:53,2),'LineWidth',3.5,'Color','k')
xlabel('Non-Agricultural Employment Share')
ylabel('Manufacturing Employment Share')
axis([0.3 1 0.1 0.45])
legend('South Korea','Japan','Taiwan','France','Italy','Spain','Denmark','USA','Location','best')
legend boxoff
hold off
saveas(f3,['../' outdir 'f3.jpg'])

fign=fign+1;
f4=figure(fign);
plot(empsh_smooth2_x(:,strcmp(countryabb,'KOR')),empsh_smooth2(:,strcmp(countryabb,'KOR')),'LineWidth',linewidth,'Color',purple)
hold on
plot(empsh_smooth2_x(:,strcmp(countryabb,'CHN')),empsh_smooth2(:,strcmp(countryabb,'CHN')),'LineWidth',linewidth,'Color',blue)
hold on
plot(empsh_smooth2_x(:,strcmp(countryabb,'IND')),empsh_smooth2(:,strcmp(countryabb,'IND')),'LineWidth',linewidth,'Color',orange)
hold on
plot(empsh_smooth2_x(:,strcmp(countryabb,'THA')),empsh_smooth2(:,strcmp(countryabb,'THA')),'LineWidth',linewidth,'Color',yellow)
xlabel('Non-Agricultural Employment Share')
ylabel('Manufacturing Employment Share')
axis([0.1 1 0.05 0.35])
legend('South Korea','China','India','Thailand','Location','best')
legend boxoff
hold off
saveas(f4,['../' outdir 'f4.jpg'])

fign=fign+1;
f5=figure(fign);
scatter(empsh_na_peak_final,empsh_m_peak_final,'w')
text(empsh_na_peak_final,empsh_m_peak_final,manuf_peak_list)
hold on
plot(empsh_na_peak_final,empsh_m_peak_final_fit,'Color',blue,'LineWidth',2)
hold off
axis([0.55 0.9 0.15 0.45])
xlabel('Non-Agricultural Employment Share at Peak')
ylabel('Manufacturing Employment Share at Peak')
saveas(f5,['../' outdir 'f5.jpg'])

fign=fign+1;
f6=figure(fign);
plot(linspace(1880,2000,13)',usahistempshdec,'LineWidth',2)
axis([1880 2000 0 0.8])
legend('Agriculture','Manufacturing','Services','Location','best')
legend boxoff
xlabel('Year')
ylabel('Sectoral Employment Share')
saveas(f6,['../' outdir 'f6.jpg'])

fign=fign+1;
f7=figure(fign);
plot(1-usahistempsh(1:53,1),usahistempsh(1:53,2),'LineWidth',linewidth,'Color',orange)
hold on
plot(1-ha,hm,'LineWidth',linewidth,'Color',blue)
axis([0.4 1 0.2 0.35])
legend('Data','Model','Location','best')
legend boxoff
xlabel('Non-Agricultural Employment Share')
ylabel('Manufacturing Employment Share')
saveas(f7,['../' outdir 'f7.jpg'])

fign=fign+1;
f8=figure(fign);
[~,hm_peak_cfa_i]=max(hm_cfa);
hm_cfa_colors=[calypso;orange;yellow;purple;green;lightblue];
for i=1:size(hm_cfa,2)
    scatter(1-ha_cfa(hm_peak_cfa_i(i),i),hm_cfa(hm_peak_cfa_i(i),i),'filled','MarkerEdgeColor',hm_cfa_colors(i,:),'MarkerFaceColor',hm_cfa_colors(i,:))
    hold on
end
plot(empsh_na_peak_final,empsh_m_peak_final_fit,'Color',blue,'LineWidth',2)
hold off
legend([ga_cfa_str,'Data Fit'],'Location','best')
legend boxoff
axis([0.55 0.9 0.15 0.4])
xlabel('Non-Agricultural Employment Share')
ylabel('Manufacturing Employment Share')
saveas(f8,['../' outdir 'f8.jpg'])

fign=fign+1;
f9=figure(fign);
for i=1:size(hm_cfa,2)
    plot(1-ha_cfa(:,i),hm_cfa(:,i),'Color',hm_cfa_colors(i,:),'LineWidth',linewidth)
    hold on
end
axis([0.4 1 0.2 0.35])
legend(ga_cfa_str,'Location','best')
legend boxoff
xlabel('Non-Agricultural Employment Share')
ylabel('Manufacturing Employment Share')
saveas(f9,['../' outdir 'f9.jpg'])

fign=fign+1;
f10=figure(fign);
[~,hm_peak_cfs_i]=max(hm_cfs);
hm_cfs_colors=[calypso;orange;yellow;purple;green;lightblue];
for i=1:size(hm_cfs,2)
    scatter(1-ha(hm_peak_cfs_i(i),1),hm_cfs(hm_peak_cfs_i(i),i),'filled','MarkerEdgeColor',hm_cfs_colors(i,:),'MarkerFaceColor',hm_cfs_colors(i,:))
    hold on
end
plot(empsh_na_peak_final,empsh_m_peak_final_fit,'Color',blue,'LineWidth',2)
hold off
legend([gs_cfs_str,'Data Fit'],'Location','best')
legend boxoff
axis([0.55 0.9 0.15 0.4])
xlabel('Non-Agricultural Employment Share')
ylabel('Manufacturing Employment Share')
saveas(f10,['../' outdir 'f10.jpg'])

fign=fign+1;
f11=figure(fign);
for c=1:size(manuf_peak_list,1)
    scatter(prodgr_a_befpeak(strcmp(countryabb,manuf_peak_list(c)),1),prodgr_a_befpeak_m(strcmp(countryabb,manuf_peak_list(c)),1),'w')
    hold on
    text(prodgr_a_befpeak(strcmp(countryabb,manuf_peak_list(c)),1),prodgr_a_befpeak_m(strcmp(countryabb,manuf_peak_list(c)),1),manuf_peak_list(c))
    hold on
end
plot(linspace(0,0.07,size(manuf_peak_list,1))',linspace(0,0.07,size(manuf_peak_list,1))','Color',blue,'LineWidth',2,'LineStyle','--')
hold off
axis([0 0.07 0 0.07])
xlabel('Agricultural Productivity Growth (Data)')
ylabel('Agricultural Productivity Growth (Model)')
saveas(f11,['../' outdir 'f11.jpg'])

fign=fign+1;
f12=figure(fign);
for c=1:size(manuf_peak_list,1)
    scatter(prodgr_ms_befpeak(strcmp(countryabb,manuf_peak_list(c)),1),prodgr_ms_befpeak_m(strcmp(countryabb,manuf_peak_list(c)),1),'w')
    hold on
    text(prodgr_ms_befpeak(strcmp(countryabb,manuf_peak_list(c)),1),prodgr_ms_befpeak_m(strcmp(countryabb,manuf_peak_list(c)),1),manuf_peak_list(c))
    hold on
end
plot(linspace(-0.07,0.05,size(manuf_peak_list,1))',linspace(-0.07,0.05,size(manuf_peak_list,1))','Color',blue,'LineWidth',2,'LineStyle','--')
hold off
axis([-0.07 0.05 -0.07 0.05])
xlabel('Manufacturing-to-Services Productivity Growth (Data)')
ylabel('Manufacturing-to-Services Productivity Growth (Model)')
saveas(f12,['../' outdir 'f12.jpg'])

fign=fign+1;
f13=figure(fign);
for c=1:size(manuf_peak_list,1)
    scatter(empsh_m_peak(strcmp(countryabb,manuf_peak_list(c)),1),empsh_m_peak_onlya(strcmp(countryabb,manuf_peak_list(c)),1),'w')
    hold on
    text(empsh_m_peak(strcmp(countryabb,manuf_peak_list(c)),1),empsh_m_peak_onlya(strcmp(countryabb,manuf_peak_list(c)),1),manuf_peak_list(c))
    hold on
end
plot(linspace(0.15,0.45,size(manuf_peak_list,1))',linspace(0.15,0.45,size(manuf_peak_list,1))','Color',blue,'LineWidth',2,'LineStyle','--')
hold off
axis([0.15 0.45 0.15 0.45])
xlabel('Manufacturing Employment Share Peak (Data)')
ylabel('Manufacturing Employment Share Peak, only A_a (Model)')
saveas(f13,['../' outdir 'f13.jpg'])

fign=fign+1;
f14a=figure(fign);
plot([linspace(1950,2010,T-sum(isnan(empsh(:,1,strcmp(countryabb,'ARG')))))';NaN(sum(isnan(empsh(:,1,strcmp(countryabb,'ARG')))),1)],empsh(:,1,strcmp(countryabb,'ARG')),'Color',blue,'LineWidth',2)
hold on
plot([linspace(1950,2010,T-sum(isnan(vash(:,1,strcmp(countryabb,'ARG')))))';NaN(sum(isnan(vash(:,1,strcmp(countryabb,'ARG')))),1)],vash(:,1,strcmp(countryabb,'ARG')),'Color',orange,'LineWidth',2)
hold off
axis([1950 2010 0 0.45])
legend('Employment Share','Value-Added Share','Location','best')
legend boxoff
saveas(f14a,['../' outdir 'f14a.jpg'])

fign=fign+1;
f14b=figure(fign);
plot([linspace(1960,2010,T-sum(isnan(empsh(:,1,strcmp(countryabb,'VEN')))))';NaN(sum(isnan(empsh(:,1,strcmp(countryabb,'VEN')))),1)],empsh(:,1,strcmp(countryabb,'VEN')),'Color',blue,'LineWidth',2)
hold on
plot([linspace(1960,2010,T-sum(isnan(vash(:,1,strcmp(countryabb,'VEN')))))';NaN(sum(isnan(vash(:,1,strcmp(countryabb,'VEN')))),1)],vash(:,1,strcmp(countryabb,'VEN')),'Color',orange,'LineWidth',2)
hold off
axis([1960 2010 0 0.45])
legend('Employment Share','Value-Added Share','Location','best')
legend boxoff
saveas(f14b,['../' outdir 'f14b.jpg'])

fign=fign+1;
f15=figure(fign);
f15colors=[blue;orange;yellow;purple;green;lightblue;red;magenta];
for c=1:size(country_ca_nameabb,1)
    plot(empsh_smooth2_x(:,strcmp(countryabb,country_ca_nameabb(c))),ca_smooth2(:,strcmp(country_ca_nameabb,country_ca_nameabb(c))),'LineWidth',linewidth,'Color',f15colors(c,:))
    hold on
end
xlabel('Non-Agricultural Employment Share')
ylabel('Current Account Surplus (% of GDP)')
axis([0.1 1 -0.15 0.25])
legend(country_ca_name,'Location','best')
legend boxoff
hold off
saveas(f15,['../' outdir 'f15.jpg'])

fign=fign+1;
fa1=figure(fign);
plot(empsh_smooth2_x(:,strcmp(countryabb,'PHL')),empsh_smooth2(:,strcmp(countryabb,'PHL')),'LineWidth',linewidth,'Color',blue)
hold on
plot(empsh_smooth2_x(:,strcmp(countryabb,'MYS')),empsh_smooth2(:,strcmp(countryabb,'MYS')),'LineWidth',linewidth,'Color',orange)
hold on
plot(empsh_smooth2_x(:,strcmp(countryabb,'ARG')),empsh_smooth2(:,strcmp(countryabb,'ARG')),'LineWidth',linewidth,'Color',yellow)
hold on
plot(empsh_smooth2_x(:,strcmp(countryabb,'BOL')),empsh_smooth2(:,strcmp(countryabb,'BOL')),'LineWidth',linewidth,'Color',purple)
hold on
plot(empsh_smooth2_x(:,strcmp(countryabb,'CHL')),empsh_smooth2(:,strcmp(countryabb,'CHL')),'LineWidth',linewidth,'Color',green)
hold on
plot(empsh_smooth2_x(:,strcmp(countryabb,'COL')),empsh_smooth2(:,strcmp(countryabb,'COL')),'LineWidth',linewidth,'Color',lightblue)
hold on
plot(empsh_smooth2_x(:,strcmp(countryabb,'CRI')),empsh_smooth2(:,strcmp(countryabb,'CRI')),'LineWidth',linewidth,'Color',red)
hold on
plot(empsh_smooth2_x(:,strcmp(countryabb,'PER')),empsh_smooth2(:,strcmp(countryabb,'PER')),'LineWidth',linewidth,'Color',calypso)
hold on
plot(empsh_smooth2_x(:,strcmp(countryabb,'VEN')),empsh_smooth2(:,strcmp(countryabb,'VEN')),'LineWidth',linewidth,'Color',magenta)
xlabel('Non-Agricultural Employment Share')
ylabel('Manufacturing Employment Share')
axis([0.2 1 0.1 0.35])
legend('Philippines','Malaysia','Argentina','Bolivia','Chile','Colombia',...
    'Costa Rica','Peru','Venezuela','Location','best')
legend boxoff
hold off
saveas(fa1,['../' outdir 'fa1.jpg'])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%TABLES
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

empsh_peak_table=strcat(countryname(manuf_peak_listDum)',';',num2str(round(empsh_na_peak(manuf_peak_listDum),2)),';',num2str(round(empsh_m_peak(manuf_peak_listDum),2)));
writecell(empsh_peak_table, ['../' outdir 'empsh_peak_table.csv'])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%STATS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Correlation between hn* and hm*
%Correlation of Figure 5
stat_f5=corr(empsh_na_peak_final,empsh_m_peak_final);

%Correlation between agricultural productivity growth between data-model
%Before the manufacturing peak
%Correlation of Figure 11
stat_f11_table=NaN(size(manuf_peak_list,1),2);
for c=1:size(manuf_peak_list,1)
    stat_f11_table(c,1)=prodgr_a_befpeak(strcmp(countryabb,manuf_peak_list(c)),1);
    stat_f11_table(c,2)=prodgr_a_befpeak_m(strcmp(countryabb,manuf_peak_list(c)),1);
end
stat_f11=corr(stat_f11_table(:,1),stat_f11_table(:,2));

%Correlation between manufacturing/services productivity growth between data-model
%Before the manufacturing peak
%Correlation of Figure 12
stat_f12_table=NaN(size(manuf_peak_list,1),2);
for c=1:size(manuf_peak_list,1)
    stat_f12_table(c,1)=prodgr_ms_befpeak(strcmp(countryabb,manuf_peak_list(c)),1);
    stat_f12_table(c,2)=prodgr_ms_befpeak_m(strcmp(countryabb,manuf_peak_list(c)),1);
end
stat_f12=corr(stat_f12_table(:,1),stat_f12_table(:,2));
stat_f12no=corr(stat_f12_table((strcmp(manuf_peak_list,'KOR')+strcmp(manuf_peak_list,'TWN'))==0,1),...
    stat_f12_table((strcmp(manuf_peak_list,'KOR')+strcmp(manuf_peak_list,'TWN'))==0,2));

%Correlation between manufacturing peak of data and model (with only A_a)
%Correlation of Figure 13
stat_f13_table=NaN(size(manuf_peak_list,1),2);
for c=1:size(manuf_peak_list,1)
    stat_f13_table(c,1)=empsh_m_peak(strcmp(countryabb,manuf_peak_list(c)),1);
    stat_f13_table(c,2)=empsh_m_peak_onlya(strcmp(countryabb,manuf_peak_list(c)),1);
end
stat_f13=corr(stat_f13_table(:,1),stat_f13_table(:,2));

close all

