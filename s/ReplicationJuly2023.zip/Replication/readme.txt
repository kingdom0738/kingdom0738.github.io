***********************************************************
Replication Instructions
"Heterogeneous Paths of Industrialization"
Federico Huneeus and Richard Rogerson
***********************************************************

***********************************************************
Data Availability and Provenance Statements
***********************************************************

The paper uses 6 datasets. All datasets are publicly available in the sources provided below
and cited in the main text. The datasets are also included in the replication package, in the folder data/raw/.

1. ggdc_10s.txt: Employment and output of countries and sectors over time. Source: GGDC 10-Sector Databse, 2014 Release.
The full dataset and documentation can be downloaded from https://www.rug.nl/ggdc/structuralchange/previous-sector-database/10-sector-2014. 

2. historicalUSA.txt: Employment and output of the United States over time. Source: Carter et al. (2006) for pre-1930
period and BEA data starting in 1929. Consolidated version of both datasets is taken from Herrendorf et al. (2014).
Dataset can be downloaded from here: https://sites.google.com/site/valentinyiakos/home/research/gowth-and-structural-transformation.

3. exports_wb.xls: Exports as a percent of GDP of countries over time. Source: World Bank Open Data.
The full dataset and documentation can be downloaded from https://data.worldbank.org/indicator/NE.EXP.GNFS.ZS.

4. imports_wb.xls: Imports as a percent of GDP of countries over time. Source: World Bank Open Data.
The full dataset and documentation can be downloaded from https://data.worldbank.org/indicator/NE.IMP.GNFS.ZS.

5. gdp_taiwan.xls: Nominal GDP of Taiwan over time. Source: International Financial Statistics (IFS) from the International Monetary Fund (IMF).
The full dataset and documentation can be downloaded from https://www.imf.org/external/datamapper/NGDPD@WEO/TWN?zoom=TWN&highlight=TWN.

6. trade_taiwan.xlsx: Exports and imports of Taiwan over time. Source: International Financial Statistics (IFS) from the International Monetary Fund (IMF).
The full dataset and documentation can be downloaded from https://fred.stlouisfed.org/series/VALEXPTWM052N#0 (exports) and https://fred.stlouisfed.org/series/VALIMPTWM052N#0 (imports).

***********************************************************
Replication Steps
***********************************************************

1. Run in Matlab the code codes/data_1.m. This code takes the raw data and prepares it for the main analysis.

2. Run in Matlab the code codes/main_analysis_2.m. This code implements the main analysis using the output file from Step 1 
and produces all the figures, tables and statistics reported in the paper. All the output will be automatically saved in
the folder output/.

***********************************************************
Software and Hardware Requirements
***********************************************************

Software: The replication only requires using Matlab. The version used by authors was MATLAB R2021b. Older versions should also work.
The authors did not use special packages to run the codes.

Hardware: The replication codes take around 2 minutes to run in total in a standard 2021 desktop machine.

***********************************************************
***********************************************************

***********************************************************
Data References
***********************************************************

Carter, S. B., S. S. Gartner, M. R. Haines, A. L. Olmstead, R. Sutch, and G. W.
(Eds.) (2006). Historical Statistics of the United States, Earliest Times to the Present:
Millennial Edition. Cambridge University Press, New York.

Herrendorf, B., R. Rogerson, and A ́kos Valentinyi (2014). Chapter 6 - growth and struc- tural transformation. In P. Aghion and S. N. Durlauf (Eds.), Handbook of Economic Growth, Volume 2 of Handbook of Economic Growth, pp. 855 – 941. Elsevier.
https://sites.google.com/site/valentinyiakos/home/research/gowth-and-structural-transformation

International Monetary Fund: International Financial Statistics.
https://data.imf.org/?sk=4c514d48-b6ba-49ed-8ab9-52b0c1a0179b

International Monetary Fund, Goods, Value of Imports for Taiwan Province of China [VALIMPTWM052N], 
retrieved from FRED, Federal Reserve Bank of St. Louis; 
https://fred.stlouisfed.org/series/VALIMPTWM052N. 

International Monetary Fund, Goods, Value of Exports for Taiwan Province of China [VALEXPTWM052N], 
retrieved from FRED, Federal Reserve Bank of St. Louis; 
https://fred.stlouisfed.org/series/VALEXPTWM052N. 

The World Bank: World Bank Open Data, Imports of Goods and Services: 
World Bank national accounts data and OECD National Accounts data files,
https://data.worldbank.org/indicator/NE.IMP.GNFS.ZS.

The World Bank: World Bank Open Data, Exports of Goods and Services: 
World Bank national accounts data and OECD National Accounts data files,
https://data.worldbank.org/indicator/NE.EXP.GNFS.ZS

Timmer, M. P., G. J. de Vries, and K. de Vries (2015). Patterns of structural change in
developing countries. In J. Weiss and M. Tribe (Eds.), Routledge Handbook of Industry
and Development, pp. 65 – 83. Routledge. 
